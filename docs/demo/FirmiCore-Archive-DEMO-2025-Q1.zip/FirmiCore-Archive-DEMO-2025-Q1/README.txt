FirmiCore ආරක්ෂිත වාර්තා ලේඛනාගාරය (DEMO)
1) මෙම ZIP ගොනුව සම්පූර්ණයෙන් EXTRACT කරන්න (Windows: ගොනුව මත දකුණු ක්ලික් -> Extract All).
2) extract කළ ෆෝල්ඩරයේ index.html දෙවරක් ක්ලික් කර බ්‍රවුසරයෙන් විවෘත කරන්න.
3) අන්තර්ජාලය හෝ FirmiCore ගිණුමක් අවශ්‍ය නැත.
EN: Extract the whole ZIP first, then open index.html in any browser. No internet or login needed.

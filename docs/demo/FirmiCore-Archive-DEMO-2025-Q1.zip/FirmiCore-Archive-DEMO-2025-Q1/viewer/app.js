(function(){
var A=window.ARCHIVE, lang='si', tab='wo', sel=null, q='', flt='';
var T={
 si:{title:'ආරක්ෂිත වාර්තා ලේඛනාගාරය',period:'කාල සීමාව',made:'සාදන ලද්දේ',tabs:{wo:'කාර්ය ඇණවුම්',bd:'බිඳවැටීම්',wp:'වැඩ අවසර',inv:'ඉන්වෙන්ටරි',po:'මිලදී ගැනීම්',ver:'සත්‍යාපනය'},
  search:'සොයන්න (අංකය, යන්ත්‍රය, පුද්ගලයා…)',all:'සියල්ල',none:'වාර්තාවක් නැත',pick:'වම් පස ලැයිස්තුවෙන් වාර්තාවක් තෝරන්න',
  f:{machine:'යන්ත්‍රය',type:'වර්ගය',status:'තත්ත්වය',opened:'විවෘත කළේ',closed:'වසා දැමූ දිනය',tech:'තාක්ෂණික',sup:'අධීක්ෂක',desc:'විස්තරය',root:'මූල හේතුව',done:'කළ වැඩ',parts:'භාවිත කළ කොටස්',labor:'ශ්‍රම පිරිවැය',partsCost:'කොටස් පිරිවැය',total:'මුළු පිරිවැය',check:'පරීක්ෂා ලැයිස්තුව',att:'ඇමුණුම්',pdf:'වාර්තාවේ PDF',sev:'බරපතලකම',down:'නිෂ්ක්‍රිය පැය',rep:'වාර්තා කළේ',cat:'වර්ගය',area:'ස්ථානය',valid:'වලංගු කාලය',issuer:'නිකුත් කළේ',prec:'ආරක්ෂණ පියවර',qty:'ප්‍රමාණය',stock:'තොගය',min:'අවම',date:'දිනය',part:'කොටස',mv:'චලනය',ref:'යොමුව',supplier:'සැපයුම්කරු',amount:'මුදල',open:'විවෘත කරන්න',size:'ප්‍රමාණය',by:'උඩුගත කළේ',parts_list:'කොටස් ලැයිස්තුව',moves:'තොග චලන',csv:'Excel (CSV) ගොනුව'},
  verHead:'ගොනු සහ checksum',verText:'සෑම ගොනුවකම SHA-256 අගය පහත ඇත. ගොනුව වෙනස් වී නැති බව තහවුරු කිරීමට පරිගණකයේ checksum මෙවලමකින් සසඳන්න.',lang:'English'},
 en:{title:'Records archive',period:'Period',made:'Created',tabs:{wo:'Work orders',bd:'Breakdowns',wp:'Work permits',inv:'Inventory',po:'Purchase orders',ver:'Verify'},
  search:'Search (number, machine, person…)',all:'All',none:'No records',pick:'Pick a record from the list on the left',
  f:{machine:'Machine',type:'Type',status:'Status',opened:'Opened',closed:'Closed',tech:'Technician',sup:'Supervisor',desc:'Description',root:'Root cause',done:'Work done',parts:'Parts used',labor:'Labour cost',partsCost:'Parts cost',total:'Total cost',check:'Checklist',att:'Attachments',pdf:'Record PDF',sev:'Severity',down:'Downtime (h)',rep:'Reported by',cat:'Category',area:'Area',valid:'Valid',issuer:'Issued by',prec:'Precautions',qty:'Qty',stock:'Stock',min:'Min',date:'Date',part:'Part',mv:'Movement',ref:'Reference',supplier:'Supplier',amount:'Amount',open:'Open',size:'Size',by:'Uploaded by',parts_list:'Parts list',moves:'Stock movements',csv:'Excel (CSV) file'},
  verHead:'Files and checksums',verText:'The SHA-256 of every file is listed below. Compare with a checksum tool to confirm a file was not changed.',lang:'සිංහල'}
};
function t(){return T[lang]}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function money(n){return 'LKR '+Number(n||0).toLocaleString('en-US')}
function kb(n){return n>1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB'}
function isImg(a){return /\.(jpe?g|png|webp|gif)$/i.test(a.name)}
function list(){
  var d=tab==='wo'?A.workOrders:tab==='bd'?A.breakdowns:tab==='wp'?A.permits:tab==='po'?A.purchaseOrders:[];
  return d.filter(function(r){
    var hay=(r.number+' '+r.machine+' '+(r.technician||'')+' '+(r.reporter||'')+' '+(r.supplier||'')+' '+(r.category||'')).toLowerCase();
    return (!q||hay.indexOf(q.toLowerCase())>=0)&&(!flt||r.status===flt||r.type===flt||r.severity===flt);
  });
}
function filterOpts(){
  var d=tab==='wo'?A.workOrders:tab==='bd'?A.breakdowns:tab==='wp'?A.permits:A.purchaseOrders, set={};
  d.forEach(function(r){var k=r.type||r.severity||r.status; if(k) set[k]=1});
  return Object.keys(set);
}
function attHtml(r){
  if(!r.attachments||!r.attachments.length) return '';
  var imgs=r.attachments.filter(isImg), files=r.attachments.filter(function(a){return !isImg(a)});
  var h='<h4>'+t().f.att+' ('+r.attachments.length+')</h4><div class="gal">';
  imgs.forEach(function(a){h+='<figure class="th" data-src="'+esc(a.path)+'" data-cap="'+esc(a.name)+'"><img src="'+esc(a.path)+'" alt=""><figcaption>'+esc(a.name)+'<br><small>'+kb(a.size)+' · '+esc(a.by||'')+'</small></figcaption></figure>'});
  h+='</div>';
  if(files.length){h+='<ul class="files">';files.forEach(function(a){h+='<li><span class="ic">📄</span><a href="'+esc(a.path)+'" target="_blank">'+esc(a.name)+'</a> <small>'+kb(a.size)+' · '+esc(a.by||'')+'</small></li>'});h+='</ul>'}
  return h;
}
function row(k,v){return v==null||v===''?'':'<div class="r"><span>'+k+'</span><b>'+v+'</b></div>'}
function detail(r){
  var F=t().f,h='<h2>'+esc(r.number)+' <em class="pill">'+esc(r.status||r.severity||'')+'</em></h2>';
  if(tab==='wo'){
    h+=row(F.machine,esc(r.machine))+row(F.type,esc(r.type))+row(F.opened,esc(r.openedAt))+row(F.closed,esc(r.closedAt))+row(F.tech,esc(r.technician))+row(F.sup,esc(r.supervisor))+row(F.desc,esc(r.description))+row(F.root,esc(r.rootCause))+row(F.done,esc(r.workDone));
    if(r.parts&&r.parts.length){h+='<h4>'+F.parts+'</h4><table>';r.parts.forEach(function(p){h+='<tr><td>'+esc(p.name)+'</td><td>× '+p.qty+'</td><td>'+money(p.cost)+'</td></tr>'});h+='</table>'}
    h+=row(F.partsCost,money(r.partsCost))+row(F.labor,money(r.laborCost))+row(F.total,'<b>'+money(r.partsCost+r.laborCost)+'</b>');
    if(r.checklist){h+='<h4>'+F.check+'</h4><ul class="chk">';r.checklist.forEach(function(c){h+='<li>'+(c.done?'☑':'☐')+' '+esc(c.item)+'</li>'});h+='</ul>'}
  } else if(tab==='bd'){
    h+=row(F.machine,esc(r.machine))+row(F.sev,esc(r.severity))+row(F.opened,esc(r.openedAt))+row(F.closed,esc(r.closedAt))+row(F.down,esc(r.downtimeHours))+row(F.rep,esc(r.reporter))+row(F.desc,esc(r.description))+row(F.root,esc(r.rootCause))+row(F.done,esc(r.workDone));
  } else if(tab==='wp'){
    h+=row(F.cat,esc(r.category))+row(F.area,esc(r.area))+row(F.valid,esc(r.valid))+row(F.issuer,esc(r.issuer))+row(F.closed,esc(r.closedAt));
    if(r.precautions){h+='<h4>'+F.prec+'</h4><ul class="chk">';r.precautions.forEach(function(c){h+='<li>☑ '+esc(c)+'</li>'});h+='</ul>'}
  } else if(tab==='po'){
    h+=row(F.supplier,esc(r.supplier))+row(F.date,esc(r.date))+row(F.amount,money(r.amount))+row(F.status,esc(r.status));
  }
  if(r.pdf) h+='<p class="pdfl">'+'<a class="btn" href="'+esc(r.pdf)+'" target="_blank">📄 '+F.pdf+'</a></p>';
  h+=attHtml(r);
  return h;
}
function render(){
  var X=t(); document.documentElement.lang=lang;
  document.getElementById('hd').innerHTML='<div><div class="co">'+esc(A.meta.company)+'</div><h1>'+X.title+'</h1><div class="sm">'+X.period+': '+esc(A.meta.period)+' · '+X.made+': '+esc(A.meta.created)+'</div></div><button id="lg">'+X.lang+'</button>';
  var tabs='';['wo','bd','wp','inv','po','ver'].forEach(function(k){tabs+='<button class="tab'+(k===tab?' on':'')+'" data-t="'+k+'">'+X.tabs[k]+'</button>'});
  document.getElementById('tabs').innerHTML=tabs;
  var main=document.getElementById('main');
  if(tab==='inv'){
    var h='<div class="wide"><h3>'+X.f.parts_list+'</h3><table class="grid"><tr><th>ID</th><th>'+X.f.part+'</th><th>'+X.f.stock+'</th><th>'+X.f.min+'</th></tr>';
    A.parts.forEach(function(p){h+='<tr><td>'+esc(p.id)+'</td><td>'+esc(p.name)+'</td><td>'+p.stock+'</td><td>'+p.min+'</td></tr>'});
    h+='</table><h3>'+X.f.moves+'</h3><table class="grid"><tr><th>'+X.f.date+'</th><th>'+X.f.part+'</th><th>'+X.f.mv+'</th><th>'+X.f.qty+'</th><th>'+X.f.ref+'</th></tr>';
    A.movements.forEach(function(m){h+='<tr><td>'+esc(m.date)+'</td><td>'+esc(m.part)+'</td><td>'+esc(m.type)+'</td><td>'+m.qty+'</td><td>'+esc(m.ref)+'</td></tr>'});
    h+='</table><p class="sm">'+X.f.csv+': <a href="data/parts.csv">parts.csv</a> · <a href="data/stock_movements.csv">stock_movements.csv</a></p></div>';
    main.innerHTML=h; return;
  }
  if(tab==='ver'){
    var v='<div class="wide"><h3>'+X.verHead+'</h3><p class="sm">'+X.verText+'</p><table class="grid"><tr><th>'+X.f.part.replace(X.f.part,'File')+'</th><th>'+X.f.size+'</th><th>SHA-256</th></tr>';
    A.files.forEach(function(f){v+='<tr><td><a href="'+esc(f.path)+'" target="_blank">'+esc(f.path)+'</a></td><td>'+kb(f.size)+'</td><td class="mono">'+esc(f.sha256.slice(0,24))+'…</td></tr>'});
    main.innerHTML=v+'</table></div>'; return;
  }
  var L=list(), opts=filterOpts();
  var left='<div class="left"><input id="q" placeholder="'+esc(X.search)+'" value="'+esc(q)+'"><select id="fl"><option value="">'+X.all+'</option>'+opts.map(function(o){return '<option'+(o===flt?' selected':'')+'>'+esc(o)+'</option>'}).join('')+'</select><div class="items">';
  L.forEach(function(r){left+='<div class="it'+(sel&&sel.number===r.number?' on':'')+'" data-n="'+esc(r.number)+'"><b>'+esc(r.number)+'</b><span>'+esc(r.machine)+'</span><small>'+esc(r.closedAt||r.date||'')+' · '+((r.attachments||[]).length)+' 📎</small></div>'});
  if(!L.length) left+='<p class="sm">'+X.none+'</p>';
  left+='</div></div>';
  main.innerHTML=left+'<div class="right" id="dt">'+(sel&&L.indexOf(sel)>=0?detail(sel):'<p class="sm">'+X.pick+'</p>')+'</div>';
}
document.addEventListener('click',function(e){
  var el=e.target.closest('[data-t],[data-n],.th,#lg,#lb');
  if(!el) return;
  if(el.id==='lg'){lang=lang==='si'?'en':'si';render();return}
  if(el.id==='lb'){el.remove();return}
  if(el.dataset.t){tab=el.dataset.t;sel=null;q='';flt='';render();return}
  if(el.dataset.n){sel=list().filter(function(r){return r.number===el.dataset.n})[0];render();return}
  if(el.classList.contains('th')){var d=document.createElement('div');d.id='lb';d.innerHTML='<img src="'+el.dataset.src+'"><p>'+esc(el.dataset.cap)+'</p>';document.body.appendChild(d)}
});
document.addEventListener('input',function(e){if(e.target.id==='q'){q=e.target.value;var p=e.target.selectionStart;render();var n=document.getElementById('q');n.focus();n.setSelectionRange(p,p)}});
document.addEventListener('change',function(e){if(e.target.id==='fl'){flt=e.target.value;render()}});
render();
})();
